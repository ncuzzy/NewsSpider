/**
 * 用户信息
 */
var mongoose = require('./db.js'),
    Schema = mongoose.Schema;

var ItemSchema = new Schema({          
    digest : { type: String },                    
    title: {type: String},                       
    time: {type: String},                        
    commentCount : { type: String},                       
    source : { type: String },                   
    category: {type: String},                      
    content: {type: String},                     
},{collection:'WangYiNews'});

module.exports = mongoose.model('Item',ItemSchema,collection='WangYiNews');