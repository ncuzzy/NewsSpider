var Item = require("./item.js");

function getAll(){
    
    Item.find({}, function(err, res){
        if (err) {
            console.log("Error:" + err);
        }
        else {
            console.log("Res:" + res);
        }
    })
}

getAll();
