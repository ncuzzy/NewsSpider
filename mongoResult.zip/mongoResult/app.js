var express = require('express');
//引入express模块
var path = require('path');
//引入path模块为了指向静态资源
var port = 80;
//指定端口变量的值
var app = express();
//app这个Object表示express应用
var mongodb = require("mongodb"); 
//引入mongoose模块
var server = new mongodb.Server('45.76.193.35',27017,{auto_reconnect:true});  
//var db = mongoose.connect("mongodb://45.76.193.35:27017/News"); 
//const mydb = db.db('News');
var db = new mongodb.Db("News",server,{safe:false});
//指定mongodb连接的数据库地址,格式为mongoose(“mongodb://user:pass@localhost:port/database”)，本demo中使用的库名为player
var Item = require('./Schemas/item');

//打开数据库连接
db.open(function(err,db){  
  if(err){  
      console.log(err);  
      return false;  
  }
  else
      console.log('connect!');
});

app.use(express.static(path.join(__dirname, 'public')));
//指定静态资源位置
app.set('views','./views');
//指定视图位置
app.set('view engine','ejs');
//指定模板引擎
app.listen(port);
//监听80端口


var link = function(db){
  return function(req,res){
  db.collection('WangYiNews', {safe:true}, function(err, collection){
  /*collection方法用于连接现有表，{safe:true} 选项，当collection不存在的时候报错
  createCollection方法用于创建新表，{safe:true} 选项，当collection存在的时候报错
  */
   if(err){
       console.log(err);
   }
   else{
       console.log('get collection!');
       collection.find().toArray(function(err,docs){
       console.log('find');
       res.render('itemlist',{itemlist:docs});
       });
   }
  });
  }
}

//下面的内容是模板加载的关键，在最后细说
app.get('/result',link(db));