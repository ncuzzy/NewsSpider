var http = require('http');
var mongoose = require('mongoose');

http.createServer(function (req, res) {
	res.writeHead(200, {'Content - Type’: ‘text / plain’,‘Access - Control - Allow - Origin’:‘http://localhost'});
	console.log('Request received: ');
	mongoose.connect('mongodb://45.76.193.35:27017/News');
	var db = mongoose.connection;
	var data = '';
	db.on('error', console.error.bind(console, '连接失败'));
	db.once('open', function (ress, callback) {
    	var Schema = mongoose.Schema({          
            digest : { type: String },                    
            title: {type: String},                       
            time: {type: String},                        
            commentCount : { type: String},                       
            source : { type: String },                   
            category: {type: String},                      
            content: {type: String},                     
        },{collection:'WangYiNews'});

    	var Tag = mongoose.model('Tag', Schema);
    	var blogtext = new Tag({
        	title: '第一篇',
        	connect: '第一篇内容'
        });
        
    	blogtext.save(function (err) {
        	if (err)
            	return console.error(err);
        });
        
    	//查找所有数据
    	Tag.find(function (err, docs) {
        	if (err)
            	return console.error(err);
        	console.log(docs);
        	ress.write(data);
        	res.end();
    	});
	});
}).listen(8090, '127.0.0.1');